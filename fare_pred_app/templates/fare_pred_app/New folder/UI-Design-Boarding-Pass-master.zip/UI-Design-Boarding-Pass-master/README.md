# UI-Design-Boarding-Pass

This is source code of Youtube Channel Video Tutorial.

Channel Name: CodeFrog

Video Title: UI Design Tutorial - Boarding Pass | HTML CSS BOOTSTRAP Speed Coding

Video Link: https://youtu.be/FMShxemoIUo

Fonts used for icons: http://fontawesome.io/

Codepen: https://codepen.io/CodeFrogShow/pen/povpwew

Subscribe our Youtube Channel: https://www.youtube.com/c/codefrog

Like us on facebook: https://www.facebook.com/codefrogshow

Follow us on Twitter: https://twitter.com/CodeFrogShow

Follow us on Codepen: http://codepen.io/CodeFrogShow/

#HappyCoding
